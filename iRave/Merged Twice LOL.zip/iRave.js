/*----GLOBAL VARIABLES----*/
//is the screen on?
var active = false;
//is the menu expanded?
var isExpandedMenu = false;
//what menu are we in?
var currMenu = "mainMenu";

/*----BAND NAMES----*/
//30 seconds to twix
//Sanic! at the Disco


function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    h = checkTime(h);
    m = checkTime(m);
    document.getElementById('clock').innerHTML = h + ":" + m;
    document.getElementById('hour').innerHTML = h;
    document.getElementById('hour').innerHTML = "<b>"+h+"</b>";
    document.getElementById('minute').innerHTML = m;
    var t = setTimeout(startTime, 500);
}



function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}

/*HIDE AND SHOW FUNCTIONS*/
/*---------------------Start----------------------------*/
function hideTime(){
    document.getElementById("hour").style.visibility = "hidden";
    document.getElementById("minute").style.visibility = "hidden";

}

function showTime(){
    document.getElementById("hour").style.visibility = "visible";
    document.getElementById("minute").style.visibility = "visible";
  
}

function hideMainMenu(){
    document.getElementsByClassName("mainMenu")[0].style.visibility = "hidden";
}

function showMainMenu(){
    document.getElementsByClassName("mainMenu")[0].style.visibility = "visible";      
}

function showInfoMenu(){
    document.getElementById("infoMenu").style.visibility = "visible";
}

function hideInfoMenu(){
    document.getElementById("infoMenu").style.visibility = "hidden";
}

function showCartazMenu(){
   document.getElementById("cartazMenu").style.visibility = "visible";
}

function hideCartazMenu(){
   document.getElementById("cartazMenu").style.visibility = "hidden";
}


/*----------------------End-----------------------------*/

function changeVisibility() {
    if(active){
        hideTime();
        hideMainMenu();
        active = false;
    }else{
        showTime();
        showMainMenu();
        active=true;
    }
}

function upaupa(element){
    
    var elem = document.getElementById(element);
    var table = document.getElementsByClassName("mainMenu")[0];
    var food = document.getElementById("food");
    var social = document.getElementById("social");
    var info = document.getElementById("info");
    console.log(elem.id);
    if(isExpandedMenu && elem.id === "info"){
        console.log("hi"); 
        //takes care of the transition
        goToInfoMenu();

        console.log("abrir cartaz/info geral/meteo");

    }else if(isExpandedMenu){
        ; // PARA AS OUTRAS FUNCIONALIDADES AINDA NAO IMPLEMENTADAS    
    }else{
        var scale = 2; 
        var id = setInterval(frame,5); 
        function frame(){
            if (scale == 10){
                clearInterval(id);
                if(elem.id == "social")
                    table.scroll(0, 150);

                if(elem.id == "info")
                    table.scroll(0, 300);
            } else {
                food.style.width = scale +'em';
                food.style.height = scale +'em';
                social.style.width = scale +'em';
                social.style.height = scale +'em';
                info.style.width = scale +'em';
                info.style.height = scale +'em';
                table.style.top =  7-(scale-2)*(7/7)+'%';
                table.style.left =  38-(scale-2)*(38/7) +'%';
                scale++;
                isExpandedMenu = true;
            }
        }
        document.getElementsByClassName("mainMenu")[0].scrolling = "yes";
    }
}


function resetUpaUpa(){
    var food = document.getElementById("food");
    var social = document.getElementById("social");
    var info = document.getElementById("info");
    console.log("\n\n"+currMenu+"\n\n");

    var table = document.getElementsByClassName("mainMenu")[0];
    
    if(currMenu === "mainMenu"){
        if(isExpandedMenu && table.style.visibility == "invisible"){
            food.style.width = 2 +'em';
            food.style.height = 2 +'em';
            social.style.width = 2 +'em';
            social.style.height = 2 +'em';
            info.style.width = 2 +'em';
            info.style.height = 2 +'em';
            table.style.top =  7 +'%';
            table.style.left =  38 +'%';
            isExpandedMenu = false;
            showTime();
        }else if(!isExpandedMenu){ //easy patch --- 
            console.log("pls");
        }else{
            var scale = 9; 
            var id = setInterval(frame,5);
            function frame(){
                if (scale == 1){
                    clearInterval(id);
                } else {
                    table.style.visibility = "visible";
                    food.style.width = scale +'em';
                    food.style.height = scale +'em';
                    social.style.width = scale +'em';
                    social.style.height = scale +'em';
                    info.style.width = scale +'em';
                    info.style.height = scale +'em';
                    table.style.top =  7-(scale-2)*(7/7)+'%';
                    table.style.left =  38-(scale-2)*(38/7) +'%';
                    scale--;
                }
            }
            isExpandedMenu = false;
            showTime();
        }
    }else if(currMenu = "infoMenu"){
        backToMainMenu();
    }else if(currMenu === "cartazMenu"){
        backToInfoMenu();
    }
}

/*goTo's and backTo's*/
/*---------------------Start----------------------------*/
function backToMainMenu(){
    currMenu = "mainMenu";
    //will need to add the other options
    hideInfoMenu();
    showMainMenu();
}

function goToInfoMenu(){
    currMenu = "infoMenu";
    // hides the main menu
    hideMainMenu();
    hideTime();
    //shows info menu
    showInfoMenu();
}

function goToCartazMenu(){
    currMenu = "cartazMenu";
    //hides the info menu
    hideInfoMenu();
    //shows cartaz menu
    showCartazMenu();
}

function backToInfoMenu(){
    currMenu = "infoMenu";
    //will need to add the other options
    hideCartazMenu(); 
    showInfoMenu();
}
/*--------------------End---------------------------*/

/*Menu management*/
/*---------------------Start----------------------------*/
function manageInfoMenu(element){
    var elem = document.getElementById(element);
    console.log(elem.id);
    switch(elem.id){
        case 'cartaz':
            console.log("shitty bands");
            goToCartazMenu();
            break;
        case 'infogeral':
            console.log("shitty info");
            break;
        case 'tempo':
            console.log("shitty something");
            break;
        default:
            console.log("impossible to get here!");
    }
}

function manageCartazMenu(element){
    var elem = document.getElementById(element);
    switch(elem.id){
        case 'palco1':
            console.log("palco1");
            
            break;
        case 'palco2':
            console.log("palco2");
            break;
        case 'palco3':
            console.log("palco3");
            break;
        default:
            console.log("impossible to get here!");
    }
}
/*--------------------End---------------------------*/
