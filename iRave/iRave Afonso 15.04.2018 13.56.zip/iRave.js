function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    h = checkTime(h);
    m = checkTime(m);
    document.getElementById('clock').innerHTML = h + ":" + m;
    document.getElementById('hour').innerHTML = h;
    document.getElementById('hour').innerHTML = "<b>"+h+"</b>";
    document.getElementById('minute').innerHTML = m;
    var t = setTimeout(startTime, 500);
}

function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}

var active = false;
function changeVisibility() {
    if(active){
        document.getElementById("hour").style.visibility = "hidden";
        document.getElementById("minute").style.visibility = "hidden";
        document.getElementsByClassName("shortcuts")[0].style.visibility = "hidden";
        active = false;
    }else{
        document.getElementById("hour").style.visibility = "visible";
        document.getElementById("minute").style.visibility = "visible";
        document.getElementsByClassName("shortcuts")[0].style.visibility = "visible";
        active=true;
    }
}
var isExpandedMenu = false;

function upaupa(element){
    
    var elem = document.getElementById(element);
    var table = document.getElementsByClassName("shortcuts")[0];
    var food = document.getElementById("food");
    var social = document.getElementById("social");
    var info = document.getElementById("info");
    console.log(elem.id);
    if(isExpandedMenu){
        console.log("hi"); //chamar funcao paro proximo ecra
        table.style.visibility = "hidden";
        document.getElementById("hour").style.visibility = "hidden";
        document.getElementById("minute").style.visibility = "hidden";
        //openRandomMenu();
    }else{
        var scale = 2;
        // ---- ou por aqui o elem.id para ele fazer scale para ele
        var id = setInterval(frame,5); // offset junky af
        function frame(){
            if (scale == 10){
                clearInterval(id);
                
                if(elem.id == "social")
                    table.scroll(0, 150);

                if(elem.id == "info")
                    table.scroll(0, 300);

            } else {
                food.style.width = scale +'em';
                food.style.height = scale +'em';
                social.style.width = scale +'em';
                social.style.height = scale +'em';
                info.style.width = scale +'em';
                info.style.height = scale +'em';
                table.style.top =  7-(scale-2)*(7/7)+'%';
                table.style.left =  38-(scale-2)*(38/7) +'%';
                scale++;
                isExpandedMenu = true;
            }
        }
        document.getElementsByClassName("shortcuts")[0].scrolling = "yes";
    }
}

function resetUpaUpa(){
    var food = document.getElementById("food");
    var social = document.getElementById("social");
    var info = document.getElementById("info");
    
    var table = document.getElementsByClassName("shortcuts")[0];
    

    if(isExpandedMenu && table.style.visibility == "invisible"){
        food.style.width = 2 +'em';
        food.style.height = 2 +'em';
        social.style.width = 2 +'em';
        social.style.height = 2 +'em';
        info.style.width = 2 +'em';
        info.style.height = 2 +'em';
        table.style.top =  7 +'%';
        table.style.left =  38 +'%';
        isExpandedMenu = false;
    }else if(!isExpandedMenu){ //easy patch 
        console.log("pls");
    }else{
        var scale = 9; 
        var id = setInterval(frame,5);
        function frame(){
            if (scale == 1){
                clearInterval(id);
            } else {
                table.style.visibility = "visible";
                food.style.width = scale +'em';
                food.style.height = scale +'em';
                social.style.width = scale +'em';
                social.style.height = scale +'em';
                info.style.width = scale +'em';
                info.style.height = scale +'em';
                table.style.top =  7-(scale-2)*(7/7)+'%';
                table.style.left =  38-(scale-2)*(38/7) +'%';
                scale--;
            }
        }
        isExpandedMenu = false;
    }
}


function openRandomMenu() {
    
}