/*----GLOBAL VARIABLES----*/
//is the screen on?
var active = false;
//is the menu expanded?
var isExpandedMenu = false;
//what menu are we in?
var currMenu = "mainMenu";
//number of orders
var orders = 0;
//number of friends
var friends = 0;

var currOption;

/*----Is user following----*/
var subToBand1 = false;
var subToBand2 = false;
var subToBandX = false;
var subToBandY = false;
var subToBandALPHA = false;
var subToBandBETA = false;
/*----Number of followers----*/
var band1 = 123;
var band2 = 456;
var bandX = 234;
var bandY = 567;
var bandALPHA = 543;
var bandBETA = 243;

var quantidade = 1;
var preco1=8;
var preco2=1.5;
var preco3=3.5;
var preco4=1.5;
var tempo1=7;
var tempo2=5;
var tempo3=10;
var tempo4=5;


function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    h = checkTime(h);
    m = checkTime(m);
    document.getElementById('clock').innerHTML ="<b>" + h + ":" + m + "</b>";
    document.getElementById('hour').innerHTML = h;
    document.getElementById('minute').innerHTML = m;
    var t = setTimeout(startTime, 500);
}

function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}

/*HIDE AND SHOW FUNCTIONS*/
/*---------------------Start----------------------------*/
function hideClock(){
    document.getElementById("clock").style.visibility = "hidden";
    document.getElementById("clockBackground").style.visibility = "hidden";
}

function showClock(){
    /*document.getElementById("clock").style.visibility = "visible";
    document.getElementById("clockBackground").style.visibility = "visible";*/
}

function hideTime(){
    document.getElementById("hour").style.visibility = "hidden";
    document.getElementById("minute").style.visibility = "hidden";

}

function showTime(){
    document.getElementById("hour").style.visibility = "visible";
    document.getElementById("minute").style.visibility = "visible";
  
}

function hideInfoHelpIcon(){
    document.getElementById("infoHelp").style.visibility = "hidden";
}

function showInfoHelpIcon(){
    document.getElementById("infoHelp").style.visibility = "visible";
}

function hideFoodHelpIcon(){
    document.getElementById("foodHelp").style.visibility = "hidden";
}

function showFoodHelpIcon(){
    document.getElementById("foodHelp").style.visibility = "visible";
}

function hideSocialHelpIcon(){
    document.getElementById("socialHelp").style.visibility = "hidden";
}

function showSocialHelpIcon(){
    document.getElementById("socialHelp").style.visibility = "visible";
}

function hideInfoHelpText(){
    document.getElementById("infoHelpText").style.visibility = "hidden";
}

function showInfoHelpText(){
    document.getElementById("infoHelpText").style.visibility = "visible";
}

function showFoodHelpText(){
    document.getElementById("foodHelpText").style.visibility = "visible";
}

function hideFoodHelpText(){
    document.getElementById("foodHelpText").style.visibility = "hidden";
}

function showSocialHelpText(){
    document.getElementById("socialHelpText").style.visibility = "visible";
}

function hideSocialHelpText(){
    document.getElementById("socialHelpText").style.visibility = "hidden";
}


function hideWackMenu(){
    document.getElementById("wackMenu").style.visibility = "hidden";
}

function showWackMenu(){
    document.getElementById("wackMenu").style.visibility = "visible";
}

function hidePizzasCaracolMenu(){
    document.getElementById("pizzaMenu").style.visibility = "hidden";
}

function showPizzasCaracolMenu(){
    document.getElementById("pizzaMenu").style.visibility = "visible";
}

function hideMainMenu(){
    document.getElementsByClassName("mainMenu")[0].style.visibility = "hidden";
}

function showMainMenu(){
    document.getElementsByClassName("mainMenu")[0].style.visibility = "visible";      
}

function showInfoMenu(){
    document.getElementById("infoMenu").style.visibility = "visible";
}

function hideInfoMenu(){
    document.getElementById("infoMenu").style.visibility = "hidden";
}

function showCartazMenu(){
   document.getElementById("cartazMenu").style.visibility = "visible";
}

function hideCartazMenu(){
   document.getElementById("cartazMenu").style.visibility = "hidden";
}

function showBandMenu(nr){
    switch(nr){
        case 1: 
            document.getElementById("palco1Bands").style.visibility = "visible";
            break;
        case 2: 
            document.getElementById("palco2Bands").style.visibility = "visible";
            break;
        case 3: 
            document.getElementById("palco3Bands").style.visibility = "visible";
            break;
        default:
            console.log("try me");
    }
}

function hideBandMenu(){
    switch(currMenu){
        case "palco1Menu": 
            document.getElementById("palco1Bands").style.visibility = "hidden";
            break;
        case "palco2Menu": 
            document.getElementById("palco2Bands").style.visibility = "hidden";
            break;
        case "palco3Menu": 
            document.getElementById("palco3Bands").style.visibility = "hidden";
            break;
        default:
            console.log("try me");
    }
}

function showBandPage(band){
     switch(band){
        case 'band1':
            document.getElementById("band1Page").style.visibility = "visible";
            if(subToBand1){
                document.getElementById("bellBand1").style.visibility = "hidden";
                document.getElementById("ringBellBand1").style.visibility = "visible";
            }else{
                document.getElementById("bellBand1").style.visibility = "visible";
                document.getElementById("ringBellBand1").style.visibility = "hidden";               
            }
            break;
        case 'band2':
            document.getElementById("band2Page").style.visibility = "visible";
            if(subToBand2){
                document.getElementById("bellBand2").style.visibility = "hidden";
                document.getElementById("ringBellBand2").style.visibility = "visible";
            }else{
                document.getElementById("bellBand2").style.visibility = "visible";
                document.getElementById("ringBellBand2").style.visibility = "hidden";              
            }
            break;
        case 'bandX':
            document.getElementById("bandXPage").style.visibility = "visible";
            if(subToBandX){
                document.getElementById("bellBandX").style.visibility = "hidden";
                document.getElementById("ringBellBandX").style.visibility = "visible";
            }else{
                document.getElementById("bellBandX").style.visibility = "visible";
                document.getElementById("ringBellBandX").style.visibility = "hidden";

            }
            break;
        case 'bandY':
            document.getElementById("bandYPage").style.visibility = "visible";
            if(subToBandY){
                document.getElementById("bellBandY").style.visibility = "hidden";
                document.getElementById("ringBellBandY").style.visibility = "visible";
            }else{
                document.getElementById("bellBandY").style.visibility = "visible";
                document.getElementById("ringBellBandY").style.visibility = "hidden";

            }
            break;
        case 'bandALPHA':
            document.getElementById("bandALPHAPage").style.visibility = "visible";
            if(subToBandALPHA){
                document.getElementById("bellBandALPHA").style.visibility = "hidden";
                document.getElementById("ringBellBandALPHA").style.visibility = "visible";
            }else{
                document.getElementById("ringBellBandALPHA").style.visibility = "hidden";
                document.getElementById("bellBandALPHA").style.visibility = "visible";
            }
            break;
        case 'bandBETA':
            document.getElementById("bandBETAPage").style.visibility = "visible";
            if(subToBandBETA){
                document.getElementById("bellBandBETA").style.visibility = "hidden";
                document.getElementById("ringBellBandBETA").style.visibility = "visible";
            }else{
                document.getElementById("ringBellBandBETA").style.visibility = "hidden";   
                document.getElementById("bellBandBETA").style.visibility = "visible";
            }
            break;
        default:
            console.log("impossible to get here!");
    }    
}

function hideBandPage(){
     switch(currMenu){
        case 'band1':
            document.getElementById("band1Page").style.visibility = "hidden";
            document.getElementById("ringBellBand1").style.visibility = "hidden";
            document.getElementById("bellBand1").style.visibility = "hidden";
            break;
        case 'band2':
            document.getElementById("band2Page").style.visibility = "hidden";
            document.getElementById("ringBellBand2").style.visibility = "hidden";
            document.getElementById("bellBand2").style.visibility = "hidden";
            break;
        case 'bandX':
            document.getElementById("bandXPage").style.visibility = "hidden";
            document.getElementById("ringBellBandX").style.visibility = "hidden";
            document.getElementById("bellBandX").style.visibility = "hidden";
            break;
        case 'bandY':
            document.getElementById("bandYPage").style.visibility = "hidden";
            document.getElementById("ringBellBandY").style.visibility = "hidden";
            document.getElementById("bellBandY").style.visibility = "hidden";
            break;
        case 'bandALPHA':
            document.getElementById("bandALPHAPage").style.visibility = "hidden";
            document.getElementById("ringBellBandALPHA").style.visibility = "hidden";
            document.getElementById("bellBandALPHA").style.visibility = "hidden";
            break;
        case 'bandBETA':
            document.getElementById("bandBETAPage").style.visibility = "hidden";
            document.getElementById("ringBellBandBETA").style.visibility = "hidden";
            document.getElementById("bellBandBETA").style.visibility = "hidden";
            break;
        default:
            console.log("impossible to get here!");
    }    
}
function showWeatherMenu(){
    document.getElementById("tempo").style.visibility = "visible";      
}

function hideWeatherMenu(){
   document.getElementById("tempo").style.visibility = "hidden";
}

function showInfoGeralMenu(){
    document.getElementById("infogeral").style.visibility = "visible";      
}

function hideInfoGeralMenu(){
   document.getElementById("infogeral").style.visibility = "hidden";
}


function showFoodMenu(){
    document.getElementById("foodMenu").style.visibility = "visible"
}

function hideFoodMenu(){
    document.getElementById("foodMenu").style.visibility = "hidden";
}

function showSocialMenu(){
    document.getElementById("socialMenu").style.visibility = "visible";
}

function hideSocialMenu(){
    document.getElementById("socialMenu").style.visibility = "hidden";
}

function showRestaurantsMenu(){
    document.getElementById("restaurantMenu").style.visibility = "visible";
}

function hideRestaurantsMenu(){
    document.getElementById("restaurantMenu").style.visibility = "hidden";
}

function showRestaurantPage(restaurant){
    switch(restaurant){
        case 'PizzasCaracol':
            document.getElementById("pizzaMenu").style.visibility = "visible";
            break;
        case 'WackDonalds':
            document.getElementById("wackMenu").style.visibility = "visible";
    }
}

function hideWackDonaldsMenu(){
    document.getElementById("wackMenu").style.visibility = "hidden";
}

function hidePizzasCaracolMenu(){
    document.getElementById("pizzaMenu").style.visibility = "hidden";
}

function showConfirmBigWackMenu(){
	document.getElementById("confirmBigWackMenu").style.visibility = "visible";
	document.getElementById("confirmOption").style.visibility = "visible";
}

function hideConfirmBigWackMenu(){
	document.getElementById("confirmBigWackMenu").style.visibility = "hidden";
	document.getElementById("confirmOption").style.visibility = "hidden";
}

function showConfirmColaMenu(){
	document.getElementById("confirmColaMenu").style.visibility = "visible";
	document.getElementById("confirmOption").style.visibility = "visible";
}

function hideConfirmColaMenu(){
	document.getElementById("confirmColaMenu").style.visibility = "hidden";
	document.getElementById("confirmOption").style.visibility = "hidden";
}

function showConfirmPizzaMenu(){
	document.getElementById("confirmPizzaMenu").style.visibility = "visible";
	document.getElementById("confirmOption").style.visibility = "visible";
}

function hideConfirmPizzaMenu(){
	document.getElementById("confirmPizzaMenu").style.visibility = "hidden";
	document.getElementById("confirmOption").style.visibility = "hidden";
}

function showConfirmAguaMenu(){
	document.getElementById("confirmAguaMenu").style.visibility = "visible";
	document.getElementById("confirmOption").style.visibility = "visible";
}

function hideConfirmAguaMenu(){
	document.getElementById("confirmAguaMenu").style.visibility = "hidden";
	document.getElementById("confirmOption").style.visibility = "hidden";
}

function showArrows(){
	document.getElementById("up_arrow").style.visibility = "visible";
	document.getElementById("down_arrow").style.visibility = "visible";
}

function hideArrows(){
	document.getElementById("up_arrow").style.visibility = "hidden";
	document.getElementById("down_arrow").style.visibility = "hidden";
}

function showQuantity(){
	quantidade = 0;
	document.getElementById("quantidade").innerHTML=0;
	document.getElementById("quantidade").style.visibility = "visible";
	document.getElementById("euros").style.visibility = "visible";
	document.getElementById("minutos").style.visibility = "visible";
	inc_quantity();
}

function hideQuantity(){
	document.getElementById("quantidade").style.visibility = "hidden";
	document.getElementById("euros").style.visibility = "hidden";
	document.getElementById("minutos").style.visibility = "hidden";
}

function showCheckBigWack(eta,amm){
	var today = new Date();
	document.getElementById("bigWackPedido").style.visibility = "visible";
	document.getElementById("cancel").style.visibility= "visible";
	document.getElementById("eta").style.visibility= "visible";
	document.getElementById("eta").innerHTML=eta-today.getHours()*60-today.getMinutes();
	document.getElementById("amm").style.visibility= "visible";
	document.getElementById("amm").innerHTML=amm+"x";
}

function hideCheckBigWack(){
	document.getElementById("bigWackPedido").style.visibility = "hidden";
	document.getElementById("cancel").style.visibility= "hidden";
	document.getElementById("eta").style.visibility= "hidden";
	document.getElementById("amm").style.visibility= "hidden";
}

function showCheckCola(eta,amm){
	var today = new Date();
	document.getElementById("colaPedido").style.visibility = "visible";
	document.getElementById("cancel").style.visibility= "visible";
	document.getElementById("eta").style.visibility= "visible";
	document.getElementById("eta").innerHTML=eta-today.getHours()*60-today.getMinutes();
	document.getElementById("amm").style.visibility= "visible";
	document.getElementById("amm").innerHTML=amm+"x";
}

function hideCheckCola(){
	document.getElementById("colaPedido").style.visibility = "hidden";
	document.getElementById("cancel").style.visibility= "hidden";
	document.getElementById("eta").style.visibility= "hidden";
	document.getElementById("amm").style.visibility= "hidden";
}

function showCheckPizza(eta,amm){
	var today = new Date();
	document.getElementById("pizzaPedido").style.visibility = "visible";
	document.getElementById("cancel").style.visibility= "visible";
	document.getElementById("eta").style.visibility= "visible";
	document.getElementById("eta").innerHTML=eta-today.getHours()*60-today.getMinutes();
	document.getElementById("amm").style.visibility= "visible";
	document.getElementById("amm").innerHTML=amm+"x";
}

function hideCheckPizza(){
	document.getElementById("pizzaPedido").style.visibility = "hidden";
	document.getElementById("cancel").style.visibility= "hidden";
	document.getElementById("eta").style.visibility= "hidden";
	document.getElementById("amm").style.visibility= "hidden";
}

function showCheckAgua(eta,amm){
	var today = new Date();
	document.getElementById("aguaPedido").style.visibility = "visible";
	document.getElementById("cancel").style.visibility= "visible";
	document.getElementById("eta").style.visibility= "visible";
	document.getElementById("eta").innerHTML=eta-today.getHours()*60-today.getMinutes();
	document.getElementById("amm").style.visibility= "visible";
	document.getElementById("amm").innerHTML=amm+"x";
}

function hideCheckAgua(){
	document.getElementById("aguaPedido").style.visibility = "hidden";
	document.getElementById("cancel").style.visibility= "hidden";
	document.getElementById("eta").style.visibility= "hidden";
	document.getElementById("amm").style.visibility= "hidden";
}

function hideSetinhas(){
	document.getElementById("up").style.visibility= "hidden";
	document.getElementById("down").style.visibility= "hidden";
}

function hideLoading(){
    document.getElementById("loading").style.visibility= "hidden";
}

function showLoading(){
    document.getElementById("loading").style.visibility= "visible";
}

function hideListaAmigos(){
    document.getElementById("listaAmigos").style.visibility= "hidden";
}

function showListaAmigos(){
    document.getElementById("listaAmigos").style.visibility= "visible";
}

function showCheckAmigo(){
	document.getElementById("findAmigo").style.visibility = "visible";
	document.getElementById("removeAmigo").style.visibility= "visible";
}

function hideCheckAmigo(){
	document.getElementById("findAmigo").style.visibility = "hidden";
	document.getElementById("removeAmigo").style.visibility= "hidden";
}

function showRemoveAmigo(){
	document.getElementById("confirmAmigo").style.visibility = "visible";
	document.getElementById("removeNo").style.visibility= "visible";
	document.getElementById("removeYes").style.visibility= "visible";
}

function hideRemoveAmigo(){
	document.getElementById("confirmAmigo").style.visibility = "hidden";
	document.getElementById("removeNo").style.visibility= "hidden";
	document.getElementById("removeYes").style.visibility= "hidden";
}

/*----------------------End-----------------------------*/

function changeVisibility() {
    if(active){
        hideTime();
        hideMainMenu();
        active = false;
    }else{
        showTime();
        showMainMenu();
        active=true;
    }
}

function upaupa(element){
    
    var elem = document.getElementById(element);
    var table = document.getElementsByClassName("mainMenu")[0];
    var food = document.getElementById("food");
    var social = document.getElementById("social");
    var info = document.getElementById("info");
    console.log(elem.id);
    if(isExpandedMenu && elem.id === "info"){
        console.log("hi"); 
        //takes care of the transition
        goToInfoMenu();
        showInfoHelpIcon();
        console.log("abrir cartaz/info geral/meteo");

    }else if(isExpandedMenu && elem.id === "food"){
        goToFoodMenu();
        showFoodHelpIcon();
        console.log("novo pedido e gerir pedidos"); 

    }else if(isExpandedMenu && elem.id === "social"){
        goToSocialMenu();
        showSocialHelpIcon();
        console.log("novo pedido e gerir pedidos"); 

    }else{
        var scale = 0; 
        var id = setInterval(frame,5); 
        function frame(){
            if (scale == 11){
                clearInterval(id);
                hideTime();
                showClock();
                console.log("upa");
            } else {
                food.style.width = 2.6 + scale*(7.7/10) +'em';
                food.style.height = 2.6 + scale*(7.4/10) +'em';
                social.style.width = 2.6 + scale*(7.7/10) +'em';
                social.style.height = 2.6 + scale*(7.4/10) +'em';
                info.style.width = 2.6 + scale*(7.7/10) +'em';
                info.style.height = 2.6 + scale*(7.4/10) +'em';
                table.style.top =  10 -(scale)*(5/10)+'%';
                table.style.left =  57-(scale)*(39/10) +'%';
                if(elem.id == "social")
                    table.scroll(0, scale*(164/10));
                if(elem.id == "info")
                    table.scroll(0, scale*(341/10));
                scale++;
                isExpandedMenu = true;
                document.getElementById("up").style.visibility = "hidden";
				document.getElementById("down").style.visibility = "visible";
            }
        }
        document.getElementsByClassName("mainMenu")[0].scrolling = "yes";
    }
}


function resetUpaUpa(){
    var food = document.getElementById("food");
    var social = document.getElementById("social");
    var info = document.getElementById("info");
    console.log("\n\n"+currMenu+"\n\n");

    var table = document.getElementsByClassName("mainMenu")[0];
    
    if(currMenu === "mainMenu"){
        if(isExpandedMenu && table.style.visibility == "invisible"){
            food.style.width = 2.6 +'em';
            food.style.height = 2.6 +'em';
            social.style.width = 2.6 +'em';
            social.style.height = 2.6 +'em';
            info.style.width = 2.6 +'em';
            info.style.height = 2.6 +'em';
            table.style.top =  12 +'%';
            table.style.left =  46 +'%';
            isExpandedMenu = false;
            showTime();
            hideClock();
            console.log("reset");
            hideSetinhas();
        }else if(!isExpandedMenu){ //easy patch --- 
            console.log("pls");
            hideSetinhas();
        }else{
            var scale = 0; 
            var id = setInterval(frame,5);
            function frame(){
                if (scale > 10){
                    clearInterval(id);
                } else {
                    table.style.visibility = "visible";
                    food.style.width = 10.3-scale*(7.7/10) +'em';
                    food.style.height = 10-scale*(7.4/10) +'em';
                    social.style.width = 10.3-scale*(7.7/10) +'em';
                    social.style.height = 10-scale*(7.4/10) +'em';
                    info.style.width = 10.3-scale*(7.7/10) +'em';
                    info.style.height = 10-scale*(7.4/10) +'em';
                    table.style.top =  5+scale*(5/10)+'%';
                    table.style.left =  18+scale*(39/10) +'%';
                    scale++;
                    console.log(food.style.height);
                    hideSetinhas();

                }
            hideSetinhas();
            }
            isExpandedMenu = false;
            showTime();
            hideClock();
        }
    }else if(currMenu === "infoMenu"){
        backToMainMenu();
        hideInfoHelpIcon();
        setinhas('main');
    }else if(currMenu === "cartazMenu"){
        backToInfoMenu();
        setinhas('infoMenu');
    }else if(currMenu === "palco1Menu" || currMenu === "palco2Menu" || currMenu === "palco3Menu" ){
        backToCartazMenu();
        setinhas('cartazMenu');
    }else if(currMenu === "band1" || currMenu === "band2" || currMenu === "bandX" || currMenu === "bandY" || currMenu === "bandALPHA" || currMenu === "bandBETA"){
        backToBandMenu(currMenu);
    }else if(currMenu === "band1" || currMenu === "band2" || currMenu === "bandX" || currMenu === "bandY" || currMenu === "bandALPHA" || currMenu === "bandBETA"){
        backToBandMenu(currMenu);
    }else if(currMenu === "infoGeralMenu"){
        backToInfoMenu();
        setinhas('infoMenu');
    }else if(currMenu === "weatherMenu"){
        backToInfoMenu();
        setinhas('infoMenu');
    }else if(currMenu === "infoHelpMenu"){
        hideInfoHelpText();
        backToInfoMenu();
        setinhas('infoMenu');
    }else if(currMenu === "foodMenu"){
        hideFoodMenu();
        hideFoodHelpIcon();
        backToMainMenu();
        setinhas('main');
    }else if(currMenu === "restaurantsMenu"){
        hideRestaurantsMenu();
        backToFoodMenu();
        hideSetinhas();
    }else if(currMenu === "foodHelpMenu"){
        hideFoodHelpText();
        backToFoodMenu();
    }else if(currMenu === "WackDonalds" || currMenu === "PizzasCaracol"){
        backToRestaurantsMenu();
        setinhas('restaurantMenu');
    }else if(currMenu === "confirmBigWackMenu" || currMenu === "confirmColaMenu"){
        backToWackMenu();
    }else if(currMenu === "confirmPizzaMenu" || currMenu === "confirmAguaMenu"){
        backToPizzasCaracolMenu();
    }else if(currMenu === "checkBigWack"){
    	hideCheckBigWack();
    	backToFoodMenu();
    }else if(currMenu === "checkCola"){
    	hideCheckCola();
    	backToFoodMenu();
    }else if(currMenu === "checkPizza"){
    	hideCheckPizza();
    	backToFoodMenu();
    }else if(currMenu === "checkAgua"){
    	hideCheckAgua();
    	backToFoodMenu();
    }else if(currMenu === "socialMenu"){
        hideSocialMenu();
        hideSocialHelpIcon();
        backToMainMenu();
        setinhas('main');
    }else if(currMenu === "socialHelpMenu"){
        hideSocialHelpText();
        backToSocialMenu();
    }else if(currMenu === "addAmigoMenu"){
        hideLoading();
        clearTimeout(timeoutAdd1);
        clearTimeout(timeoutAdd2);
        document.getElementById("sample").style.visibility= "hidden";
        setinhas('socialMenu');
        backToSocialMenu();
    }else if(currMenu === "listaAmigos"){
        hideListaAmigos();
        setinhas('socialMenu');
        backToSocialMenu();
    }else if(currMenu === "checkAmigo"){
    	currMenu="listaAmigos";
        hideCheckAmigo();
        showListaAmigos();
    }else if(currMenu === "findAmigo"){
    	currMenu="checkAmigo";
        //hideFindAmigo();
        showCheckAmigo();
    }else if(currMenu === "removeAmigo"){
    	currMenu="checkAmigo";
        hideRemoveAmigo();
        showCheckAmigo();
    }

}

/*goTo's and backTo's*/
/*---------------------Start----------------------------*/
function backToMainMenu(){
    currMenu = "mainMenu";
    //will need to add the other options
    hideInfoMenu();
    hideFoodMenu();
    showMainMenu();
}
function goToSocialMenu(){
    currMenu = "socialMenu";
    hideMainMenu();
    hideTime();
    showSocialMenu();
}

function goToFoodMenu(){
    currMenu = "foodMenu";
    hideMainMenu();
    hideTime();
    showFoodMenu();
}

function goToInfoMenu(){
    currMenu = "infoMenu";
    // hides the main menu
    hideMainMenu();
    hideTime();
    //shows info menu
    showInfoMenu();
}

function backToInfoMenu(){
    currMenu = "infoMenu";
    hideCartazMenu();
    hideWeatherMenu();
    hideInfoGeralMenu();
    showInfoHelpIcon();
    showInfoMenu();
}

function goToCartazMenu(){
    currMenu = "cartazMenu";
    //hides the info menu
    hideInfoMenu();
    //shows cartaz menu
    showCartazMenu();
}

function backToCartazMenu(){
    //hides the band menu
    hideBandMenu();
    //shows cartaz menu
    showCartazMenu();
    currMenu = "cartazMenu";
}

function goToBandMenu(nr){
    currMenu = "palco" + nr + "Menu";
    hideCartazMenu(); 
    showBandMenu(nr);
}

function backToBandMenu(band){
    hideBandPage();
    switch(band){
        case "band1":
            currMenu = "palco1Menu"
            showBandMenu(1);
            break;
        case "band2":
            currMenu = "palco1Menu"
            showBandMenu(1);
            break;
        case "bandX":
            currMenu = "palco2Menu"
            showBandMenu(2);
            break;
        case "bandY":
            currMenu = "palco2Menu"
            showBandMenu(2);
            break;
        case "bandALPHA":
            currMenu = "palco3Menu"
            showBandMenu(3);
            break;
        case "bandBETA":
            currMenu = "palco3Menu"
            showBandMenu(3);
            break;
        default:
            console.log("try me");
    }
}

function goToBandPage(band){
    hideBandMenu();
    currMenu = band;
    showBandPage(band);
}


function backToBandMenu(band){
    hideBandPage();
    switch(band){
        case 'band1':
            currMenu = 'palco1Menu';
            showBandMenu(1);
            break;
        case 'band2':
            currMenu = 'palco1Menu';
            showBandMenu(1);
            break;
        case 'bandX':
            currMenu = 'palco2Menu';
            showBandMenu(2);
            break;
        case 'bandY':
            currMenu = 'palco2Menu';
            showBandMenu(2);
            break;
        case 'bandALPHA':
            currMenu = 'palco3Menu';
            showBandMenu(3);
            break;
        case 'bandBETA':
            currMenu = 'palco3Menu';
            showBandMenu(3);
            break;
        default:
            console.log("impossible to get here!");
    }
}

function goToWeatherMenu(){
    currMenu = "weatherMenu";
    hideInfoMenu(); 
    showWeatherMenu();
}

function goToInfoHelp(){
    currMenu = "infoHelpMenu";
    hideInfoHelpIcon();
    hideInfoMenu();
    hideSetinhas();
    showInfoHelpText();
}

function goToFoodHelp(){
    currMenu = "foodHelpMenu";
    hideFoodHelpIcon();
    hideFoodMenu();
    showFoodHelpText();
}

function goToSocialHelp(){
    currMenu = "socialHelpMenu";
    hideSocialHelpIcon();
    hideSocialMenu();
    showSocialHelpText();
}

function goToInfoGeralMenu(){
    currMenu = "infoGeralMenu";
    hideInfoMenu(); 
    showInfoGeralMenu();
}

function goToRestaurantsMenu(){
    currMenu = "restaurantsMenu";
    hideFoodMenu();
    showRestaurantsMenu();
    hideFoodHelpIcon();
}

function backToFoodMenu(){
    currMenu = "foodMenu";
    hideRestaurantsMenu();
    showFoodHelpIcon();
    showFoodMenu();
}

function goToRestaurantPage(restaurant){
    hideRestaurantsMenu();
    currMenu = restaurant;
    showRestaurantPage(restaurant);
}

function backToRestaurantsMenu(){
    currMenu = "restaurantsMenu";
    hideWackDonaldsMenu();
    hidePizzasCaracolMenu();
    showRestaurantsMenu();
}

function goToConfirmBigWack(){
    currMenu = "confirmBigWackMenu";
    showConfirmBigWackMenu();
    showArrows();
    showQuantity();
}

function goToConfirmCola(){
    currMenu = "confirmColaMenu";
    showConfirmColaMenu();
    showArrows();
    showQuantity();
}

function backToWackMenu(){
    currMenu = "WackDonalds";
    hideConfirmBigWackMenu();
    hideConfirmColaMenu();
    hideArrows();
    hideQuantity();
    showWackMenu();
}

function goToConfirmPizza(){
    currMenu = "confirmPizzaMenu";
    showConfirmPizzaMenu();
    showArrows();
    showQuantity();
}

function goToConfirmAgua(){
    currMenu = "confirmAguaMenu";
    showConfirmAguaMenu();
    showArrows();
    showQuantity();
}

function backToPizzasCaracolMenu(){
    currMenu = "PizzasCaracol";
    hideConfirmPizzaMenu();
    hideConfirmAguaMenu();
    hideArrows();
    hideQuantity();
    showPizzasCaracolMenu();
}

function goToCheckBigWack(eta,amm){
	currMenu = "checkBigWack";
	hideFoodMenu();
	hideFoodHelpIcon();
	showCheckBigWack(eta,amm);
}

function goToCheckCola(eta,amm){
	currMenu = "checkCola";
	hideFoodMenu();
	hideFoodHelpIcon();
	showCheckCola(eta,amm);
}

function goToCheckPizza(eta,amm){
	currMenu = "checkPizza";
	hideFoodMenu();
	hideFoodHelpIcon();
	showCheckPizza(eta,amm);
}

function goToCheckAgua(eta,amm){
	currMenu = "checkAgua";
	hideFoodMenu();
	hideFoodHelpIcon();
	showCheckAgua(eta,amm);
}

function backToSocialMenu(){
    currMenu = "socialMenu";
    showSocialHelpIcon();
    showSocialMenu();
}


function goToCheckAmigo(){
	console.log("amiguinho");
	currMenu = "checkAmigo";
	hideListaAmigos();
	showCheckAmigo();
}

var timeoutAdd1;
var timeoutAdd2;
function goToAddAmigoMenu(){
    currMenu = "addAmigoMenu";
    showLoading();
    var table = document.getElementById("listaAmigos");

    timeoutAdd1 = setTimeout(function(){
    	document.getElementById("loading").style.visibility= "hidden";
    	document.getElementById("sample").style.visibility= "visible";
    	var row = table.insertRow(friends);
	    var cell1 = row.insertCell(0);
	    cell1.className = "friend";
	    friends++;
    	document.getElementsByClassName("friend")[document.getElementsByClassName("friend").length-1].setAttribute("onClick", "goToCheckAmigo()");
		},1500);

    


    timeoutAdd2 = setTimeout(function(){
    	document.getElementById("sample").style.visibility= "hidden";
    	showSocialMenu();
    	setinhas('socialMenu');},3000);
}

function goToListaAmigos(){
    currMenu = "listaAmigos";
    showListaAmigos();
}

function goToFindAmigo(){
	currMenu = "findAmigo";
	hideCheckAmigo();
	//showFindAmigo();
}

function goToRemoveAmigo(){
	currMenu = "removeAmigo";
	hideCheckAmigo();
	showRemoveAmigo();
}


/*--------------------End---------------------------*/

/*Menu management*/
/*---------------------Start----------------------------*/
function manageInfoMenu(element){
    var elem = document.getElementById(element);
    console.log(elem.id);
    switch(elem.id){
        case 'cartaz':
            goToCartazMenu();
            hideInfoHelpIcon();
            break;
        case 'infogeral':
            goToInfoGeralMenu();
            hideInfoHelpIcon();
            break;
        case 'tempo':
            goToWeatherMenu();
            hideInfoHelpIcon();
            break;
        default:
            console.log("impossible to get here!");
    }
}

function manageCartazMenu(element){
    var elem = document.getElementById(element);
    switch(elem.id){
        case 'palco1':
            console.log("palco1");
            goToBandMenu(1);
            break;
        case 'palco2':
            console.log("palco2");
            goToBandMenu(2);
            break;
        case 'palco3':
            console.log("palco3");
            goToBandMenu(3);
            break;
        default:
            console.log("impossible to get here!");
    }
}

function manageBandMenu(element){
    var elem = document.getElementById(element);
    goToBandPage(elem.id);  
}

function manageSocialMenu(element){
    var elem = document.getElementById(element);
    console.log(elem.id);
    switch(elem.id){
        case 'amigo':
            hideSocialMenu();
            hideSocialHelpIcon();
            goToAddAmigoMenu();
            break;
        case 'lista':
            hideSocialMenu();
            hideSocialHelpIcon();
            hideSetinhas();
            goToListaAmigos();
            break;
        default:
            console.log("impossible to get here!");
    }
}


/*--------------------End---------------------------*/

function sub(band){ 
    switch(band){ 
        case 'band1': 
            if(!subToBand1){ 
                document.getElementById("bellBand1").style.visibility = "hidden"; 
                document.getElementById("ringBellBand1").style.visibility = "visible"; 
                subToBand1 = true; 
                band1++; 
            }else{ 
                document.getElementById("bellBand1").style.visibility = "visible"; 
                document.getElementById("ringBellBand1").style.visibility = "hidden"; 
                subToBand1 = false; 
                band1--; 
            } 

            document.getElementById('displayCountBand1').innerHTML = band1; 
            break; 

        case 'band2': 
            if(!subToBand2){ 
                document.getElementById("bellBand2").style.visibility = "hidden";
                document.getElementById("ringBellBand2").style.visibility = "visible"; 
                subToBand2 = true; 
                band2++; 
            }else{ 
                document.getElementById("bellBand2").style.visibility = "visible"; 
                document.getElementById("ringBellBand2").style.visibility = "hidden"; 
                subToBand2 = false; 
                band2--; 
            } 

            document.getElementById('displayCountBand2').innerHTML = band2; 
            break; 

        case 'bandX': 
            if(!subToBandX){
                document.getElementById("bellBandX").style.visibility = "hidden"; 
                document.getElementById("ringBellBandX").style.visibility = "visible"; 
                subToBandX = true; 
                bandX++; 
            }else{ 
                document.getElementById("bellBandX").style.visibility = "visible"; 
                document.getElementById("ringBellBandX").style.visibility = "hidden"; 
                subToBandX = false; 
                bandX--; 
            } 

            document.getElementById('displayCountBandX').innerHTML = bandX; 
            break; 

        case 'bandY': 
            if(!subToBandY){ 
                document.getElementById("bellBandY").style.visibility = "hidden"; 
                document.getElementById("ringBellBandY").style.visibility = "visible"; 
                subToBandY = true; 
                bandY++; 
            }else{ 
                document.getElementById("bellBandY").style.visibility = "visible"; 
                document.getElementById("ringBellBandY").style.visibility = "hidden"; 
                subToBandY = false; 
                bandY--; 
            } 
 
            document.getElementById('displayCountBandY').innerHTML = bandY; 
            break;

        case 'bandALPHA': 
            if(!subToBandALPHA){ 
                document.getElementById("bellBandALPHA").style.visibility = "hidden"; 
                document.getElementById("ringBellBandALPHA").style.visibility = "visible"; 
                subToBandALPHA = true; 
                bandALPHA++;
            }else{ 
                document.getElementById("bellBandALPHA").style.visibility = "visible"; 
                document.getElementById("ringBellBandALPHA").style.visibility = "hidden"; 
                subToBandALPHA = false; 
                bandALPHA--; 
            } 

            document.getElementById('displayCountBandALPHA').innerHTML = bandALPHA; 
            break; 

        case 'bandBETA': 
            if(!subToBandBETA){ 
                document.getElementById("bellBandBETA").style.visibility = "hidden"; 
                document.getElementById("ringBellBandBETA").style.visibility = "visible"; 
                subToBandBETA = true; 
                bandBETA++; 
            }else{ 
                document.getElementById("bellBandBETA").style.visibility = "visible"; 
                document.getElementById("ringBellBandBETA").style.visibility = "hidden"; 
                subToBandBETA = false; 
                bandBETA--; 
            } 

            document.getElementById('displayCountBandBETA').innerHTML = bandBETA; 
            break; 

        default: 
            console.log("hi there!");
    } 
}

function addPedido() {
    var table = document.getElementById("foodMenu");
    var today = new Date();
    orders++;
    var row = table.insertRow(orders);
    var cell1 = row.insertCell(0);
    var amm = document.getElementById("quantidade").innerHTML;
  	if(currMenu=="confirmBigWackMenu"){
  		cell1.className = "orderBigWack";
  		eta=tempo1*amm+today.getMinutes()+today.getHours()*60;
    	document.getElementsByClassName("orderBigWack")[document.getElementsByClassName("orderBigWack").length-1].setAttribute("onClick", "checkPedido('bigwack',"+eta+","+amm+",this.parentElement.rowIndex)" );
    	//document.getElementsByClassName("orderBigWack")[orders-1].setAttribute("onClick", "deletePedido(this.parentElement)" );
    	hideConfirmBigWackMenu();
    	hideRestaurantsMenu();
    	hideWackDonaldsMenu();
    	hideArrows();
    	hideQuantity();
    	showFoodHelpIcon();
    	currMenu="foodMenu";
  	}

  	if(currMenu=="confirmColaMenu"){
  		cell1.className = "orderCola";
  		eta=tempo2*amm+today.getMinutes()+today.getHours()*60;
    	document.getElementsByClassName("orderCola")[document.getElementsByClassName("orderCola").length-1].setAttribute("onClick", "checkPedido('cola',"+eta+","+amm+",this.parentElement.rowIndex)" );
    	hideConfirmColaMenu();
    	hideRestaurantsMenu();
    	hideWackDonaldsMenu();
    	hideArrows();
    	hideQuantity();
    	showFoodHelpIcon();
    	currMenu="foodMenu";
  	}

  	if(currMenu=="confirmPizzaMenu"){
  		cell1.className = "orderPizza";
  		eta=tempo3*amm+today.getMinutes()+today.getHours()*60;
    	document.getElementsByClassName("orderPizza")[document.getElementsByClassName("orderPizza").length-1].setAttribute("onClick", "checkPedido('fatiadepizza',"+eta+","+amm+",this.parentElement.rowIndex)" );
    	hideConfirmPizzaMenu();
    	hideRestaurantsMenu();
    	hidePizzasCaracolMenu();
    	hideArrows();
    	hideQuantity();
    	showFoodHelpIcon();
    	currMenu="foodMenu";
  	}

  	if(currMenu=="confirmAguaMenu"){
  		cell1.className = "orderAgua";
  		eta=tempo4*amm+today.getMinutes()+today.getHours()*60;
    	document.getElementsByClassName("orderAgua")[document.getElementsByClassName("orderAgua").length-1].setAttribute("onClick", "checkPedido('agua',"+eta+","+amm+",this.parentElement.rowIndex)" );
    	hideConfirmAguaMenu();
    	hideRestaurantsMenu();
    	hidePizzasCaracolMenu();
    	hideArrows();
    	hideQuantity();
    	showFoodHelpIcon();
    	currMenu="foodMenu";
  	}
    console.log("orders = " + orders);
    showFoodMenu();
}

function deletePedido(){
    document.getElementById("foodMenu").deleteRow(currOption);
    orders--;
    hideCheckAgua();
    hideCheckPizza();
    hideCheckCola();
    hideCheckBigWack();
    showFoodMenu();
    showFoodHelpIcon();
}

function checkPedido(consumable, amm, eta, option){
	console.log("option "+option);
	currOption=option;
	switch(consumable){ 
        case 'bigwack':       
        	goToCheckBigWack(amm,eta);
            break; 

        case 'cola':
        	goToCheckCola(amm,eta);
            break; 

        case 'fatiadepizza':  
        	goToCheckPizza(amm,eta);
            break; 

        case 'agua':
        	goToCheckAgua(amm,eta);
            break; 

        default: 
            console.log("hi there!");
    }
}

function confirmOrder(consumable){
	hideWackMenu();
	hidePizzasCaracolMenu();
	switch(consumable){ 
        case 'bigwack':       
        	goToConfirmBigWack();
            break; 

        case 'cola':
        	goToConfirmCola();
            break; 

        case 'fatiadepizza':  
        	goToConfirmPizza();
            break; 

        case 'agua':
        	goToConfirmAgua();
            break; 

        default: 
            console.log("hi there!");
    }
    document.getElementById("down_arrow").style.visibility = "hidden";
}

function inc_quantity(){
    if(quantidade != 9){
    	quantidade++;
    	document.getElementById("quantidade").innerHTML = quantidade;
    	if(currMenu=="confirmBigWackMenu"){
    		document.getElementById("euros").innerHTML = quantidade*preco1;
    		document.getElementById("minutos").innerHTML = quantidade*tempo1;
    	}
    	if(currMenu=="confirmColaMenu"){
    		document.getElementById("euros").innerHTML = quantidade*preco2;
    		document.getElementById("minutos").innerHTML = quantidade*tempo2;
    	}
    	if(currMenu=="confirmPizzaMenu"){
    		document.getElementById("euros").innerHTML = quantidade*preco3;
    		document.getElementById("minutos").innerHTML = quantidade*tempo3;
    	}
    	if(currMenu=="confirmAguaMenu"){
    		document.getElementById("euros").innerHTML = quantidade*preco4;
    		document.getElementById("minutos").innerHTML = quantidade*tempo4;
    	}
        document.getElementById("down_arrow").style.visibility = "visible";
        
        if(quantidade == 9){
            document.getElementById("up_arrow").style.visibility = "hidden";
        }
    }
}

function dec_quantity(){
	if(quantidade != 1){
		quantidade--;
		document.getElementById("quantidade").innerHTML = quantidade;
		if(currMenu=="confirmBigWackMenu"){
			document.getElementById("euros").innerHTML = quantidade*preco1;
			document.getElementById("minutos").innerHTML = quantidade*tempo1;
		}
		if(currMenu=="confirmColaMenu"){
			document.getElementById("euros").innerHTML = quantidade*preco2;
			document.getElementById("minutos").innerHTML = quantidade*tempo2;
		}
		if(currMenu=="confirmPizzaMenu"){
			document.getElementById("euros").innerHTML = quantidade*preco3;
			document.getElementById("minutos").innerHTML = quantidade*tempo3;
		}
		if(currMenu=="confirmAguaMenu"){
			document.getElementById("euros").innerHTML = quantidade*preco4;
			document.getElementById("minutos").innerHTML = quantidade*tempo4;
		}	
        document.getElementById("up_arrow").style.visibility = "visible";
	
        if(quantidade == 1){
            document.getElementById("down_arrow").style.visibility = "hidden";
        }
    }

}

function setinhas(idname){
	var table = document.getElementById(idname);

	console.log("scrolltop " + table.scrollTop);
	console.log("scrollHeight " + table.scrollHeight);

	if(currMenu === "foodMenu"){
		hideSetinhas();
	}

	else if(table.scrollTop === 0){
		document.getElementById("up").style.visibility = "hidden";
		document.getElementById("down").style.visibility = "visible";
	}

	else if(table.scrollHeight - table.scrollTop === table.clientHeight){
		document.getElementById("down").style.visibility = "hidden";
		document.getElementById("up").style.visibility = "visible";
	}

	else{
		document.getElementById("up").style.visibility = "visible";
		document.getElementById("down").style.visibility = "visible";
	}

	if(currMenu === "mainMenu" && !isExpandedMenu)
		hideSetinhas();	
}

function RemoveNo(){
	currMenu="checkAmigo";
	hideRemoveAmigo();
	showCheckAmigo();
}

function RemoveYes(){
	currMenu="listaAmigo";
	hideRemoveAmigo();
	document.getElementById("listaAmigos").deleteRow(friends-1);
    friends--;
	goToListaAmigos();
}

function doubleClick(){
    hideTime();
    hideInfoMenu();
    hideBandPage();
    hideBandMenu();
    hideCartazMenu();
    hideMainMenu();
    hideWeatherMenu();
    hideInfoGeralMenu();
    hideInfoHelpIcon();
    hideFoodHelpIcon();
    hideFoodMenu();
    hideRestaurantsMenu();
    showTime();
    showMainMenu();
    document.getElementsByClassName("mainMenu")[0].style.visibility = "visible";
    currMenu = "mainMenu";
    resetUpaUpa();
}

